var Scale = "0.9"; 
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "id", "fr", "de", or "it"
var refreshrate = 10; // update interval of weather, in minutes
var DarkMode = true; 
var BGColor = ""; 
var TextColor = ""; 
var WeatherIcon = 1; // 1= white, 2= black
