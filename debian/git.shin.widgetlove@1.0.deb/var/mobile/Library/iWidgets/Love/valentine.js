
function tym() {
	this.x = rand(ww)
	this.y = rand(wh)
	this.z = rand(wh)
	this.c = rand(300)
	this.s = 2
	this.draw = function () {
		var k = ww / this.z
		var x = (this.x - ww/2) * k + ww/2
		var y = (this.y - wh/2) * k + wh/2
		begin()
			arc(x, y, this.r, 90, 270)
			lineWidth(this.r * 2)
			lineCap('round')
			stroke('hsla(' + this.c + ', 100%, 50%, ' + opacity + ')')
		close()
	}
	this.update = function () {
		this.draw()
		this.z += this.s
		this.r = ww / this.z * 1.5
	  if(this.z > wh) this.z = 1;
	}
}
var tyms = []
for(var i = 0; i < wh; i++)
		tyms.push(new tym());
function setup () {
   cw = widthCanvas - 0
   ch = heightCanvas - 0
prevent = true
stoppp = true
}
function honkai (){
clear()
   globalAlpha(opacity - 0)
   background(backgroundColor)
	tyms.forEach(function (d) {
		d.update()
	})
loop()
}