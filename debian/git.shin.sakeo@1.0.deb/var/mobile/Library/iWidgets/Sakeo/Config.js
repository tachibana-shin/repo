var Scale = "1.3"; // choose the widget size from "0.1 to 3.0"
var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "es", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "jp", "kr", "tr"
